#include <bits/stdc++.h>

using namespace std;

int main(){
    string a = "-4.2";
    double b = stod(a);
    cout << b;
}
