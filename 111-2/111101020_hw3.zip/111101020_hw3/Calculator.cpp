#include "Calculator.h"
#include <termios.h>
#include <bits/stdc++.h>
using namespace std;

Calculator::Calculator() {
    exit = false;
}
bool Calculator::pressEqual = false;
bool Calculator::exit = false;
string Calculator::expression = "";
void Calculator::exitWindow(View* view) {
    Calculator::exit = true;
}
void Calculator::pressSymbolButton(View* view) {
    if (pressEqual) {
        display->setOutput("");
        expression = "";
        pressEqual = false;
    }
    expression += dynamic_cast<Button*>(view)->getText();
    display->setOutput(expression);
    display->render();
}

void Calculator::pressEqualButton(View* view) {
    pressEqual = true;
    dynamic_cast<Label*>(display)->setOutput(to_string(Calculator::evaluate(expression)));
}

double Calculator::evaluate(string a) {

    vector<double> nums;
    vector<char> operations;
    double tem = 0, float_tem = 0;
    int float_num = 1;
    bool is_float = false, negative = false;
    for(int i=0; i<a.length(); i++){
        if(isdigit(a[i])){
            if(!is_float){
                tem *= 10;
                tem += int(a[i]-'0');
            }else{
                float_tem += int(a[i]-'0')/pow(10, float_num)*1.0;
                float_num ++;
            }
            
        }else if(a[i] == '.'){
            is_float = true;
        }else if(a[i] == '-' && (!isdigit(a[i-1]) + (i==0))){
            negative = true;
        }else{
            
            if(negative){
                nums.push_back(-1*(tem+float_tem));
            }else{
                nums.push_back(tem+float_tem);
            }
            operations.push_back(a[i]);
            tem = 0;
            float_tem = 0;
            float_num = 1;
            negative = false;
            is_float = false;
        }
        if(i==a.length()-1){
            if(negative){
                nums.push_back(-1*(tem+float_tem));
            }else{
                nums.push_back(tem+float_tem);
            }
            tem = 0;
            float_tem = 0;
            float_num = 1;
            negative = false;
            is_float = false;
        }
    }
    Node* head = new Node();
    Node *pre = head;
    Node *temm = head;
    head->data = nums[0];
    for(int i=1; i<nums.size(); i++){
        Node* new_node = new Node();
        new_node->data = nums[i];
        pre->next = new_node;
        pre = pre->next;
    }
//    for(int i=0; i<nums.size(); i++){
//        cout << nums[i] << " "<< operations[i] << " ";
//    }
//    cout << endl;
    pre = head;
    for(int i=0; i<operations.size(); i++){
        if(i==0){
            head->operation =operations[i];
        }else{
            pre = pre->next;
            pre->operation = operations[i];
        }

    }
    head = temm;
    while(!all_plusandsub(temm)){
        
        while(head != NULL){

            if( head -> operation == '*'){
                head -> data *= head -> next -> data;
                head -> operation = head -> next -> operation;
                
                Node* f = head -> next;
                
                head -> next = head -> next -> next;
                
                delete f;
                
            }else if( head -> operation == '/'){
                head -> data /= head -> next -> data;
                head -> operation = head -> next -> operation;
                
                Node* f = head -> next;
                
                head -> next = head -> next -> next;
                
                delete f;
            }
//            cout << head->data << endl;
            if(head->operation=='*' || head->operation=='/'){
                
            }else{
                head = head->next;
            }
            
            
        }
//        cout << 1;
        head = temm;
        
    }
    
    head = temm;
    while(temm->next!=NULL){
        
        while(head != NULL){

            if( head -> operation == '+'){
                head -> data += head -> next -> data;
                head -> operation = head -> next -> operation;
                
                Node* f = head -> next;
                
                head -> next = head -> next -> next;
                delete f;
            }else if( head -> operation == '-'){
                head -> data -= head -> next -> data;
                head -> operation = head -> next -> operation;
                
                Node* f = head -> next;
                
                head -> next = head -> next -> next;
                delete f;
            }
            head = head->next;
        }
//        cout << 1;
        head = temm;
        
    }
    
    head = temm;
    
//    while(temm->next!=NULL){
//        while(head != NULL){
//
//            if( head -> operation == '+'){
//                head -> data += head -> next -> data;
//                head -> operation = head -> next -> operation;
//                head -> next = head -> next -> next;
//            }else if( head -> operation == '-'){
//                head -> data -= head -> next -> data;
//                head -> operation = head -> next -> operation;
//                head -> next = head -> next -> next;
//            }
//            head = head->next;
//        }
//        head = temm;
//    }
    int dddd = temm->data;
    delete temm;
    
    return dddd;
}


void Calculator::run() {
    struct termios ter;
    tcgetattr(0, &ter);
    ter.c_lflag &= ~ICANON;
    tcsetattr(0, TCSANOW, &ter);

    window->render();
    while (!Calculator::exit) {
        char key;
        key = cin.get();
        if (key == 27) {
            key = cin.get();
            if (key == 91) {
                key = cin.get();
                ArrowKey arrowKey;
                if (key == 65) {
                    arrowKey = ArrowKey::UP;
                } else if (key == 66) {
                    arrowKey = ArrowKey::DOWN;
                } else if (key == 67) {
                    arrowKey = ArrowKey::RIGHT;
                } else if (key == 68) {
                    arrowKey = ArrowKey::LEFT;
                }
                window->onArrowKeyPress(arrowKey);
            }
        } else if (key == 10) {
            window->onEnterPress();
        }
        window->render();
    }
}

Calculator::~Calculator(){
    delete window;
}
